/* Bounded read-only PSP syscall-table inspection for the owned worker. */
#ifndef NODS_SYSCALL_SNAPSHOT_H
#define NODS_SYSCALL_SNAPSHOT_H
#include <stdint.h>
#include <string.h>
typedef uint32_t (*NodsSysRead)(uint32_t,void *);
typedef struct {unsigned originals[4],hooks[4],tables,error;uint32_t root,seed;} NodsSysSnapshot;
static inline uint32_t nods_sys_address(uint32_t a){return a?(a&0x1fffffffu)|0x80000000u:0;}
static inline int nods_sys_range(uint32_t a,unsigned n){return !(a&3)&&a>=0x88000000u&&a<0x88800000u&&n<=0x88800000u-a;}
static inline void nods_sys_snapshot(uint32_t root,const uint32_t originals[4],const uint32_t hooks[4],NodsSysRead read,void *opaque,NodsSysSnapshot *out){
 uint32_t visited[16];memset(out,0,sizeof(*out));root=nods_sys_address(root);out->root=root;
 if(!read||!root){out->error=1;return;}
 for(unsigned t=0;root&&t<16;t++){
  if(!nods_sys_range(root,16)){out->error=2;return;}
  for(unsigned j=0;j<t;j++)if(visited[j]==root){out->error=3;return;}
  visited[t]=root;uint32_t next=read(root,opaque),seed=read(root+4,opaque),size=read(root+8,opaque);
  if(!t)out->seed=seed;
  if(size<16||size>0x10000u||(size&3)||!nods_sys_range(root,size)){out->error=4;return;}
  out->tables++;
  for(unsigned i=16;i<size;i+=4){
   uint32_t value=read(root+i,opaque)&0x0fffffffu;
   for(unsigned j=0;j<4;j++){
    if(originals[j]&&value==(originals[j]&0x0fffffffu))out->originals[j]++;
    if(hooks[j]&&value==(hooks[j]&0x0fffffffu))out->hooks[j]++;
   }
  }
  root=nods_sys_address(next);
 }
 if(root)out->error=5;
}
#endif
