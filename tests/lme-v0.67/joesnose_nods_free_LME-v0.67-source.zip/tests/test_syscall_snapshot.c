#include "syscall_snapshot.h"
#include <assert.h>
#include <stdio.h>
static uint32_t words[64];static unsigned reads;
static uint32_t read_word(uint32_t a,void *opaque){(void)opaque;assert(a>=0x88010000u&&a<0x88010100u&&!(a&3));reads++;return words[(a-0x88010000u)/4];}
int main(void){
 uint32_t old[4]={0x88001000,0x88002000,0x88003000,0x88004000},hooks[4]={0x88301000,0x88302000,0x88303000,0x88304000};NodsSysSnapshot s;
 words[0]=0x88010080;words[1]=0;words[2]=32;
 words[4]=old[0];words[5]=old[1]&0x0fffffff;words[6]=hooks[2];words[7]=0;
 words[32]=0;words[33]=0x4000;words[34]=24;words[36]=old[3];words[37]=hooks[0];
 nods_sys_snapshot(0xa8010000,old,hooks,read_word,NULL,&s);
 assert(!s.error&&s.tables==2&&s.seed==0&&s.originals[0]==1&&s.originals[1]==1&&s.originals[3]==1&&s.hooks[2]==1&&s.hooks[0]==1);
 words[32]=0x88010000;nods_sys_snapshot(0x88010000,old,hooks,read_word,NULL,&s);assert(s.error==3);
 words[32]=0;words[2]=0x10004;nods_sys_snapshot(0x88010000,old,hooks,read_word,NULL,&s);assert(s.error==4);
 reads=0;nods_sys_snapshot(0x08801000,old,hooks,read_word,NULL,&s);assert(s.error==2&&!reads);
 reads=0;nods_sys_snapshot(0,old,hooks,read_word,NULL,&s);assert(s.error==1&&!reads);
 puts("PASS: read-only syscall snapshot follows zero-seed tables, matches masked originals/hooks, bounds sizes/pointers and rejects cycles without writes");
}
